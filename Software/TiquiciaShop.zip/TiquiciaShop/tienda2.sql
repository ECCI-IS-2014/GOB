-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-11-2014 a las 18:37:30
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `tienda2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Futbol'),
(2, 'Baloncesto'),
(3, 'Tenis de Mesa'),
(6, 'Volleyball');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `category` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `subcategory` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `subsubcategory` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `type` varchar(2000) COLLATE utf8_spanish_ci NOT NULL,
  `price` double NOT NULL,
  `weight` double NOT NULL,
  `unit` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dir` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `keywords` varchar(2000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `volumen` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `subsubcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `subcategory_id` (`subcategory_id`),
  KEY `subsubcategory_id` (`subsubcategory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=52 ;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `subcategory`, `subsubcategory`, `type`, `price`, `weight`, `unit`, `filename`, `dir`, `keywords`, `volumen`, `created`, `updated`, `stock`, `state`, `category_id`, `subcategory_id`, `subsubcategory_id`) VALUES
(40, 'F50 ', 'Futbol', 'Tacos', 'Adidas', 'Tacos f50 Adidas, azul con verde', 25000, 2, 'Kilogramos', 'f50.jpg', 'img\\uploads\\product\\filename', 'f50 adidas', '5', '2014-10-30 11:48:35', '2014-10-30 11:48:35', 0, 1, 1, 2, 2),
(41, 'Battle Adidas', 'Futbol', 'Tacos', 'Adidas', 'Tacos Battle, azul blanco y negro', 24000, 2, 'Kilogramos', 'battleAdidas.jpg', 'img\\uploads\\product\\filename', 'battle', '5', '2014-10-30 11:50:48', '2014-10-30 11:50:48', 0, 0, 1, 2, 2),
(42, 'Tacos Nike', 'Futbol', 'Tacos', 'Nike', 'tacos nike, altos naranja', 32000, 2, 'Kilogramos', 'nike.jpg', 'img\\uploads\\product\\filename', 'nike tacos', '5', '2014-10-30 11:51:58', '2014-10-30 11:51:58', 0, 1, 1, 2, 8),
(43, 'Balon de Volleyball MVA300', 'Volleyball', 'Balones', 'Mikasa', 'balon de volleyball mikasa', 20000, 2, 'Kilogramos', 'mikasa.jpg', 'img\\uploads\\product\\filename', 'volleyball mikasa', '10', '2014-10-30 11:55:48', '2014-10-30 11:55:48', 0, 1, 6, 9, 10),
(46, 'Battle Adidas', 'Futbol', 'Tacos', 'Adidas', 'Tacos Battle, azul blanco y negro', 24000, 2, 'Kilogramos', 'battleAdidas.jpg', 'img\\uploads\\product\\filename', 'battle', '5', '2014-10-30 11:50:48', '2014-10-30 11:50:48', 0, 0, 1, 2, 2),
(51, 'Mercurial ', 'Tenis_de_mesa', NULL, NULL, 'Tacos mercurial oscuros, negro con azul', 100, 30, NULL, 'mercurial-0.jpg', 'img\\uploads\\product\\filename', 'nike mercurial', NULL, '2014-11-02 23:01:39', '2014-11-04 18:36:32', 0, 0, 1, 2, 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subcategories`
--

CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_catid` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`) VALUES
(1, 1, 'Balones'),
(2, 1, 'Tacos'),
(3, 2, 'Tenis'),
(4, 3, 'Raquetas'),
(9, 6, 'Balones');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subsubcategories`
--

CREATE TABLE IF NOT EXISTS `subsubcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subcategory_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_subcatid` (`subcategory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `subsubcategories`
--

INSERT INTO `subsubcategories` (`id`, `subcategory_id`, `name`) VALUES
(1, 1, 'Barcelona'),
(2, 2, 'Adidas'),
(3, 3, 'Nike'),
(4, 4, 'Butterfly'),
(8, 2, 'Nike'),
(10, 9, 'Mikasa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `middle_name` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `last_name` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `identification` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `birth_date` date NOT NULL,
  `username` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `role` varchar(12) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`,`identification`,`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=18 ;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `email`, `password`, `identification`, `birth_date`, `username`, `role`) VALUES
(12, 'Dayner', 'Rafael', 'UmaÃ±a', 'darafael.5959@gmail.com', '$2a$10$UbbzG2FJ4MG6nqqaOsi/7e/mXEcKYKLKhfuDUfnTii4L/IVGjGqIO', '1111111', '1992-02-07', 'rafael', 'admin'),
(13, 'Douglas', 'Castillo', 'Chavarria', 'sdfsdf@zds', '$2a$10$pN/1Nylv84bgPbHDEC3hOuuec975frbY5m1nuQp2u/3LKQI0Wrqk6', '115430824', '1994-08-05', 'd', 'admin'),
(14, 'Alejandro', 'Cordoba', 'Soto', 'alejandro06cs@hotmail.com', '$2a$10$uKz38t2nTXa.i25ReNeL7Oq347aN7PReM6vOE6hdSOhEgMr1jfOay', '115080718', '2014-10-30', 'coba', 'customer'),
(16, 'nuevo', 'nuevo', 'nuevo', 'ada@sad', '$2a$10$Lcj68ALsqxWpjeoV/NMVEuhL8N7U4Ty938xPytS4qKIWHZGqpz8V6', '123456', '1994-01-10', 'nuevo', 'customer'),
(17, 'Alejandro', 'Reyes', 'Granados', 'ale@gmail', '$2a$10$AcRcVbRWfos3363ueAyWsOH1actihLgAkpKAqhOxSccym.vDiPhpO', '115310700', '1994-01-17', 'aler', 'customer');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `wishes`
--

CREATE TABLE IF NOT EXISTS `wishes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `wishes`
--

INSERT INTO `wishes` (`id`, `product_id`, `user_id`, `created`) VALUES
(3, 40, 16, '2014-11-02 19:59:17'),
(6, 42, 17, '2014-11-02 20:05:10');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
